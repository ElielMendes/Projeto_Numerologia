# Numerologia através do Tarot 

from flask import Flask, render_template, request
import mysql.connector

app = Flask(__name__)

@app.route("/", methods=['GET','POST'])
def numerologia_nome():
    if request.method == "GET":
        return render_template("index.html")
    else:
        nome = request.form['nome'].replace(" ", "")
        num_letras = len(nome)
        soma_nome = 0

        if num_letras > 22:
            pi_str = str(num_letras)
            for i in pi_str:
                soma_nome += int(i)
        else:
            soma_nome = num_letras
             
        conexao = mysql.connector.connect(
            host = 'localhost',
            user = 'root',
            password= 'admin',
            database= 'banco',
        )

        cursor = conexao.cursor()

        comando = f'SELECT arcano FROM banco.tarot WHERE numero = {soma_nome};'
        cursor.execute(comando)

        resultado = cursor.fetchall() 
        return render_template("resultado.html", arcano = soma_nome, coluna_arcano = resultado[0][0])